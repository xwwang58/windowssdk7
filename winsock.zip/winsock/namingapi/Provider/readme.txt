Description
-----------
The Naming Provider is the provider responsible for handling name registration and resolution requests for a given domain name

How to Build
------------
nmake (Only builds and runs under Vista)

How to Run
----------
Type SampleProvider.exe -install from an elevated window from ...\PeerToPeer\Naming\Provider
Then run SampleProvider.exe -run
After this, run the Naming Client from ...\PeerToPeer\Naming\Client


Platforms supported
-------------------
Windows Vista (except Starter Edition)
